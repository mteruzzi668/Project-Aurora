# Project Aurora V3.0

Homepage foundation for Marco Teruzzi Archive.
Next release:
- Dynamic hero
- Portfolio
- Masonry gallery
- Filters
